# Acarlar Döner NFC Ödeme Sayfası

Bu klasördeki `index.html` doğrudan statik web sitesi olarak yayınlanabilir.

## Kalıcı bağlantı
NFC karta bir kez sitenin URL'sini yazın. Daha sonra IBAN veya alıcı bilgisi değişirse `index.html` içeriğini güncelleyip aynı site adresine yeniden yayınlayın. URL değişmediği sürece NFC kartındaki bağlantıyı yeniden yazmanız gerekmez.

## GitHub Pages ile ücretsiz yayınlama
1. GitHub'da yeni bir repository oluşturun (ör. `acarlar-doner-odeme`).
2. `index.html` dosyasını repository'nin ana dizinine yükleyin.
3. Settings → Pages bölümüne girin.
4. Source olarak `Deploy from a branch`, branch olarak `main` ve klasör olarak `/ (root)` seçin.
5. Save'e basın. GitHub size `https://KULLANICIADINIZ.github.io/acarlar-doner-odeme/` biçiminde gerçek bir site adresi verecektir.
6. Bu adresi telefondan açıp butonları test edin.
7. NFC Tools → Yaz → Kayıt ekle → URL/URI → bu gerçek bağlantıyı yapıştır → karta yaz.

Not: Bu sohbet ortamından herkese açık bir alan adı/hosting hesabı oluşturamıyorum; bu nedenle yayınlanmış gibi sahte bir bağlantı vermiyorum.
